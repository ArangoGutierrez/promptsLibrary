# Claude Code Commands

Workflow commands for Claude Code that provide structured, repeatable processes for common development tasks.

## Overview

These commands are highly optimized, token-efficient prompts that guide Claude through complex workflows. Each command follows a specific structure designed for consistency and completeness.

**Format**: These files use compressed notation for token efficiency:
- `|` separates columns in tables
- `→` indicates workflow progression
- `✓` marks verification checkpoints
- `⚠` highlights warnings
- `#` references GitHub issues
- `∵` means "because"

## Available Commands

### Planning & Execution

#### 1. task.md
**Purpose**: Spec-first task execution workflow

**Phases**:
1. **UNDERSTAND** (10%): Context gathering, issue fetch, clarify requirements
2. **SPECIFY** (15%): Inputs, outputs, constraints, acceptance criteria, edge cases
3. **PLAN**: Compare approaches, select with rationale, await approval
4. **IMPLEMENT**: TDD cycle, update AGENTS.md progress
5. **VERIFY**: Tests, acceptance criteria, edge cases
6. **REFLECT**: Logic validation, completeness check
7. **COMMIT/PR**: Signed commits, PR creation

**Usage**:
```
/task "Add user authentication"
/task #123 --plan          # Plan phase only
/task "Fix bug" --tdd      # TDD mode
```

**Best for**:
- Feature development
- Bug fixes with clear acceptance criteria
- Changes requiring multi-phase planning

---

#### 2. parallel.md
**Purpose**: Execute multiple independent tasks concurrently

**Process**:
1. Task analysis (dependencies)
2. Cluster independent tasks
3. Launch parallel executions
4. Aggregate results

**Usage**:
```
/parallel "Task 1, Task 2, Task 3"
/parallel --analyze AGENTS.md
```

**Best for**:
- Multiple independent file changes
- Parallel code reviews
- Concurrent test generation

---

### Code Quality

#### 3. audit.md
**Purpose**: Deep defensive security and reliability audit

**Focus Areas**:
- Race conditions and goroutine leaks
- K8s lifecycle issues
- Security vulnerabilities (SQL injection, auth bypass)
- Resource leaks
- Error handling gaps

**Usage**:
```
/audit src/auth/
/audit --go --k8s
```

**Best for**:
- Pre-production security review
- Go/K8s codebases
- Critical path code

---

#### 4. quality.md
**Purpose**: Multi-agent comprehensive quality review

**Agents Used**:
- Auditor (security)
- Performance Critic (perf)
- API Reviewer (consistency)

**Usage**:
```
/quality src/api/
/quality --parallel
```

**Best for**:
- Pre-commit comprehensive review
- PR quality gate
- Refactoring validation

---

#### 5. self-review.md
**Purpose**: File-by-file self-review checklist

**Checks**:
- Logic correctness
- Edge case handling
- Error handling completeness
- Security considerations
- Performance implications

**Usage**:
```
/self-review
/self-review src/handlers/
```

**Best for**:
- Pre-commit self-check
- Learning code quality patterns
- Mentoring junior developers

---

### Testing

#### 6. test.md
**Purpose**: Run and verify test suites

**Process**:
1. Discover test files
2. Run tests with coverage
3. Analyze failures
4. Verify acceptance criteria

**Usage**:
```
/test
/test src/auth/
/test --coverage
```

**Best for**:
- Pre-commit test validation
- CI/CD integration
- Coverage analysis

---

### Architecture & Design

#### 7. architect.md
**Purpose**: Full architecture exploration with parallel prototyping

**Pipeline**:
```
arch-explorer → devil-advocate → [prototyper×2] → synthesizer
    ↓               ↓                 ↓              ↓
 3-5 options    challenge top    parallel impl    recommend
```

**Usage**:
```
/architect "User authentication system"
/architect "Caching strategy" --quick    # Skip prototypes
/architect "API gateway" --proto 3       # Prototype top 3
```

**Output**: Architecture Decision Record (ADR) with:
- Approaches comparison matrix
- Evidence-based recommendation
- Trade-offs analysis
- Risk mitigations
- Next steps

**Best for**:
- Major architectural decisions
- Technology selection
- Design pattern choice
- RFC authoring

---

### Research & Investigation

#### 8. research.md
**Purpose**: Deep issue research and solution brainstorming

**Process**:
1. Issue context gathering (GitHub/Jira)
2. Codebase investigation
3. Problem classification
4. Root cause analysis
5. Solution alternatives
6. Risk assessment

**Usage**:
```
/research #456
/research "Performance degradation in API"
```

**Best for**:
- Bug investigation
- Unfamiliar codebase exploration
- Solution planning

---

#### 9. issue.md
**Purpose**: Convert GitHub issue to atomic task breakdown

**Process**:
1. Fetch issue details (via MCP)
2. Extract requirements
3. Break into atomic tasks
4. Update AGENTS.md with [TODO] markers
5. Identify dependencies

**Usage**:
```
/issue #123
/issue #123 --plan-only
```

**Output**: AGENTS.md updated with task breakdown

**Best for**:
- Issue planning
- Sprint planning
- Task delegation

---

### Git Workflows

#### 10. git-polish.md
**Purpose**: Rewrite commits atomically for clean history

**Features**:
- Atomic commit separation
- Conventional commit formatting
- Signed commits (DCO + GPG)
- Interactive rebase

**Usage**:
```
/git-polish
/git-polish --squash
/git-polish --split HEAD~3
```

**Best for**:
- Cleaning up feature branch history
- Preparing for PR
- Atomic commit enforcement

---

### Development Workflows

#### 11. code.md
**Purpose**: Execute next TODO from AGENTS.md

**Process**:
1. Read AGENTS.md
2. Find first [TODO] task
3. Execute using /task workflow
4. Update task to [DONE]

**Usage**:
```
/code
/code --next 3    # Process next 3 TODOs
```

**Best for**:
- Automated task execution
- AGENTS.md workflow integration
- Sequential task processing

---

### Context Management

#### 12. context-reset.md
**Purpose**: Reset or inspect context tracking state

**Features**:
- View context health
- Reset context state
- Clear conversation history
- Session statistics

**Usage**:
```
/context-reset --status
/context-reset --clear
/context-reset --stats
```

**Best for**:
- Context health monitoring
- Starting fresh after long sessions
- Debugging context issues

---

### Debugging & Improvement

#### 13. debug.md
**Purpose**: Systematic debugging workflow for issue identification and resolution

**Phases**:
1. **Reproduce**: Define exact steps and conditions
2. **Isolate**: Narrow scope to specific code
3. **Hypothesize**: Form 2-3 theories about root cause
4. **Test**: Run experiments to validate theories
5. **Fix**: Implement minimal fix
6. **Verify**: Confirm resolution without side effects

**Usage**:
```
/debug "API returns 500 on large requests"
/debug --trace "stack trace here"
/debug --bisect    # Binary search for regression
```

**Best for**:
- Bug investigation
- Error resolution
- Regression analysis
- Production issues

---

#### 14. docs.md
**Purpose**: Generate and maintain documentation following project conventions

**Phases**:
1. **Analyze**: Identify documentation gaps
2. **Extract**: Pull signatures, types, patterns
3. **Generate**: Create docs following style
4. **Verify**: Check accuracy against code
5. **Format**: Apply consistent formatting

**Usage**:
```
/docs src/api/
/docs src/auth/ --api        # API documentation
/docs src/utils/ --readme    # Update README
/docs src/core/ --inline     # Add inline comments
/docs --verify               # Verify existing docs
```

**Best for**:
- API documentation
- README generation
- Inline comments
- Documentation verification

---

#### 15. refactor.md
**Purpose**: Systematic refactoring preserving behavior while improving quality

**Phases**:
1. **Analyze**: Identify code smells and complexity
2. **Plan**: Create refactoring plan with rationale
3. **Verify Tests**: Ensure test coverage exists
4. **Execute**: Apply transformations incrementally
5. **Validate**: Run full suite and compare

**Usage**:
```
/refactor src/handlers/
/refactor src/utils/ --safe        # Extra validation
/refactor src/core/ --aggressive   # Larger scope
```

**Best for**:
- Code smell elimination
- Complexity reduction
- Duplication removal
- Technical debt paydown

---

## Command Categories

### By Use Case

**Project Planning**:
- task.md → Single task execution
- parallel.md → Multiple concurrent tasks
- issue.md → Issue-to-tasks breakdown

**Code Quality**:
- audit.md → Security/reliability
- quality.md → Multi-aspect review
- self-review.md → Pre-commit check
- test.md → Test execution

**Architecture**:
- architect.md → Full exploration + prototypes
- research.md → Investigation + alternatives

**Debugging & Improvement**:
- debug.md → Systematic debugging
- refactor.md → Behavior-preserving refactoring
- docs.md → Documentation generation

**Git Workflow**:
- git-polish.md → Commit cleanup
- code.md → AGENTS.md integration

**Context**:
- context-reset.md → Context management

### By Complexity

**Quick** (< 2 min):
- self-review.md
- test.md
- code.md
- context-reset.md

**Medium** (2-5 min):
- audit.md
- quality.md
- git-polish.md
- issue.md
- docs.md

**Deep** (5-15 min):
- task.md
- research.md
- parallel.md
- debug.md
- refactor.md

**Comprehensive** (15+ min):
- architect.md (with prototypes)

### By Agent Usage

**Single Agent**:
- Most commands use direct execution

**Multi-Agent**:
- quality.md → auditor + perf-critic + api-reviewer
- architect.md → arch-explorer + devil-advocate + prototypers + synthesizer
- research.md → researcher agent

## Integration with Agents

Commands often invoke agents from `claude/agents/`:

```
architect.md uses:
  - arch-explorer.md
  - devil-advocate.md
  - prototyper.md
  - synthesizer.md

quality.md uses:
  - auditor.md
  - perf-critic.md
  - api-reviewer.md

research.md uses:
  - researcher.md
```

## Usage Patterns

### Pre-Commit Workflow

```bash
1. /self-review     # Quick self-check
2. /quality         # Comprehensive review
3. /test            # Run tests
4. /git-polish      # Clean commits
```

### Feature Development

```bash
1. /issue #123      # Break down issue
2. /task --plan     # Plan approach
3. /code            # Execute tasks
4. /architect       # If design decision needed
5. /test            # Verify
```

### Bug Investigation

```bash
1. /research #456   # Investigate
2. /task "Fix bug"  # Implement fix
3. /audit           # Security check
4. /test            # Verify fix
```

### Architecture Decision

```bash
1. /architect "Problem description"
   → Full pipeline with prototypes
   → ADR generated
2. Make decision
3. /task "Implement chosen approach"
```

## Not Migrated (Use Official Plugins)

These Cursor commands were **not migrated** because official Claude Code plugins exist:

### loop.md → Use ralph-wiggum plugin
```bash
# Instead of Cursor's /loop
Use official: /ralph-loop "task" --completion-promise "DONE" --max-iterations 50
```

### push.md → Use commit-commands plugin
```bash
# Instead of Cursor's /push
Use official: /commit-push-pr

# Additional official commands:
/commit           # Commit only
/clean_gone       # Clean merged branches
```

### review-pr.md → Use code-review or pr-review-toolkit plugins
```bash
# Instead of Cursor's /review-pr
Use official: /code-review            # Comprehensive 4-agent review
# OR
Use official: /pr-review-toolkit:review-pr   # 6 specialized agents
```

## Command Format Guide

### Token-Efficient Notation

These commands use compressed notation to reduce token usage:

**Symbols**:
- `|` - Column separator in tables
- `→` - Workflow progression or implies
- `↓` - Vertical flow
- `✓` - Verification checkpoint
- `⚠` - Warning or caution
- `#` - GitHub issue reference
- `∵` - "Because" (rationale)
- `≤` - Less than or equal to
- `{n}` - Variable placeholder
- `L/M/H` - Low/Medium/High

**Abbreviations**:
- P1, P2, ... - Phase 1, Phase 2, ...
- GH# - GitHub issue number
- impl - Implementation
- perf - Performance
- sec - Security
- val - Validation
- OOS - Out of scope

**Example**:
```
P1:UNDERSTAND(10%)
GH#→fetch:title,body,labels,comments
Clarify≤2q
```

Expands to:
```
Phase 1: UNDERSTAND (10% of time)
If GitHub issue: fetch title, body, labels, and comments
Clarify with at most 2 questions
```

## File Structure

```
claude/commands/
├── README.md              (this file)
├── task.md                (1.0KB) - Core workflow
├── parallel.md            (844B) - Concurrent execution
├── audit.md               (918B) - Security audit
├── quality.md             (1.2KB) - Multi-agent review
├── self-review.md         (570B) - Pre-commit check
├── test.md                (798B) - Test execution
├── architect.md           (1.2KB) - Architecture pipeline
├── research.md            (1.4KB) - Investigation workflow
├── issue.md               (961B) - Issue breakdown
├── git-polish.md          (604B) - Commit cleanup
├── code.md                (932B) - AGENTS.md executor
├── context-reset.md       (1.3KB) - Context management
├── debug.md               (5.7KB) - Debugging workflow
├── docs.md                (5.3KB) - Documentation generation
└── refactor.md            (4.6KB) - Refactoring workflow

Total: 16 files, ~28KB
```

## Deployment

Commands are deployed alongside agents and hooks:

```bash
# Local deployment
./scripts/deploy-claude.sh

# With symlinks (auto-update)
./scripts/deploy-claude.sh --symlink

# Remote installation
curl -fsSL https://raw.githubusercontent.com/user/repo/main/scripts/deploy-claude.sh | bash -s -- --download
```

After deployment, commands are available at: `~/.claude/commands/`

## Contributing

To add a new command:

1. Create `{command-name}.md` in `claude/commands/`
2. Use token-efficient format (see existing commands)
3. Include clear usage examples
4. Document agent integration if applicable
5. Add to this README
6. Update `deploy-claude.sh` to include in deployment

## Migration Notes

### From Cursor

These commands were migrated from Cursor's `_optimized/commands/` format:
- Maintained token-efficient notation
- Adapted for Claude Code's Task tool
- Updated agent references
- Added usage examples

### Differences from Official Plugins

**Commands provide**:
- Structured workflows
- Multi-phase processes
- Built-in verification steps
- AGENTS.md integration

**Official plugins provide**:
- Single-purpose skills
- Deeper integration
- Better maintained
- Official support

**Strategy**: Use official plugins where they exist, commands for unique workflows.

## Best Practices

### When to Use Commands

**Use commands for**:
- Structured workflows with phases
- Complex multi-step processes
- Repeatable patterns
- Team consistency

**Don't use commands for**:
- Simple one-off tasks
- Exploratory work
- Rapid prototyping
- Tasks requiring flexibility

### Combining Commands and Agents

**Good patterns**:
```bash
# Use command for structure, agents for depth
/architect "Problem"
  → Invokes: arch-explorer, devil-advocate, prototyper, synthesizer

/quality src/
  → Invokes: auditor, perf-critic, api-reviewer
```

**Avoid**:
```bash
# Don't nest commands within commands
# Don't manually invoke command-internal agents
```

### Token Efficiency

These commands are designed for minimal token usage:
- Use compressed notation
- Avoid verbose explanations
- Structured output formats
- Clear phase separation

## License

Same as parent project.

## See Also

- **Agents**: `claude/agents/README.md` - Specialized sub-agents
- **Hooks**: `claude/hooks/README.md` - Lifecycle automation
- **Mapping**: `cursor-to-claude-mapping.md` - Migration guide
